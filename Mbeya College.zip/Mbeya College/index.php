<?php
require_once 'includes/config.php';

// Redirect logged in users to their dashboard
if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin/dashboard.php' : 'user/dashboard.php');
}
?>

<?php include 'includes/header.php'; ?>

<div class="hero-section bg-success text-white py-5">
    <div class="container text-center">
        <h1 class="display-4 fw-bold">Welcome to Mbeya College of Agriculture</h1>
        <p class="lead">Online Application System for Prospective Students</p>
        <div class="mt-4">
            <a href="register.php" class="btn btn-light btn-lg mx-2">
                <i class="bi bi-person-plus"></i> Register
            </a>
            <a href="login.php" class="btn btn-outline-light btn-lg mx-2">
                <i class="bi bi-box-arrow-in-right"></i> Login
            </a>
        </div>
    </div>
</div>

<div class="container my-5">
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-pencil-square display-4 text-primary mb-3"></i>
                    <h3>Easy Application</h3>
                    <h3>Fill our simple online form to apply for programs at Mbeya College of Agriculture.</h3>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-clock-history display-4 text-warning mb-3"></i>
                    <h3>Track Status</h3>
                    <h3>Monitor your application status in real-time through your personal dashboard.</h3>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-credit-card display-4 text-success mb-3"></i>
                    <h3>Secure Payment</h3>
                    <h3>Make secure online payments for your application fees (Tsh 20,000/=).</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="bg-light py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2>About Mbeya College of Agriculture</h2>
                <p class="lead">Providing quality agricultural education and training to build Tanzania's agricultural sector.</p>
                <p>Our college offers various certificate and diploma programs in agriculture, livestock,
                     and related fields. We are committed to
                     producing skilled professionals who will contribute to the development of Tanzania's agricultural industry.</p>
            </div>
            <div class="col-md-6">
                <img src="image/image2.jpg" alt="College Campus" class="img-fluid rounded shadow">
            </div>
        </div>
    </div>
</div>

<div class="container my-5">
    <h2 class="text-center mb-4">Application Requirements</h2>
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3 border-0 shadow-sm">
                <div class="card-body">
                    <h4><i class="bi bi-check-circle text-success"></i> For Certificate Programs</h4>
                    <ul>
                        <li>Completed Form Four (CSEE) with at least 4 passes</li>
                        <li>Original certificates and transcripts</li>
                        <li>Birth certificate</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-3 border-0 shadow-sm">
                <div class="card-body">
                    <h4><i class="bi bi-check-circle text-success"></i> For Diploma Programs</h4>
                    <ul>
                        <li>Completed Form Six (ACSEE) with 1 principal pass</li>
                        <li>Original certificates and transcripts</li>
                        <li>Birth certificate</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>