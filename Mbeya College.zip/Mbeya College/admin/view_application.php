<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];

// Get application details with user info
$stmt = $pdo->prepare("
    SELECT a.*, u.username, u.email 
    FROM applications a 
    JOIN users u ON a.user_id = u.id 
    WHERE a.id = ?
");
$stmt->execute([$application_id]);
$application = $stmt->fetch();

if (!$application) {
    $_SESSION['error'] = "Application not found.";
    redirect('applications.php');
}
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Application Details</h4>
            <div>
                <span class="badge bg-<?= 
                    $application['application_status'] === 'approved' ? 'success' : 
                    ($application['application_status'] === 'rejected' ? 'danger' : 'warning') 
                ?> fs-6 me-2">
                    <?= ucfirst($application['application_status']) ?>
                </span>
                <span class="badge bg-<?= $application['payment_status'] === 'paid' ? 'success' : 'warning' ?> fs-6">
                    <?= ucfirst($application['payment_status']) ?>
                </span>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-6">
                <p><strong>Applicant:</strong> <?= htmlspecialchars($application['username']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($application['email']) ?></p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-2"><strong>Application Date:</strong> <?= date('d/m/Y H:i', strtotime($application['submitted_at'])) ?></p>
                <p><strong>Application ID:</strong> MCA-<?= str_pad($application['id'], 5, '0', STR_PAD_LEFT) ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Personal Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Full Name:</strong> <?= htmlspecialchars($application['full_name']) ?></p>
                        <p><strong>Date of Birth:</strong> <?= date('d/m/Y', strtotime($application['birth_date'])) ?></p>
                        <p><strong>Phone Number:</strong> <?= htmlspecialchars($application['phone']) ?></p>
                        <p><strong>Region:</strong> <?= htmlspecialchars($application['region']) ?></p>
                        <p><strong>District:</strong> <?= htmlspecialchars($application['district']) ?></p>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Primary Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Primary School:</strong> <?= htmlspecialchars($application['primary_school']) ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Secondary Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Secondary School:</strong> <?= htmlspecialchars($application['secondary_school']) ?></p>
                        <p><strong>Completion Year:</strong> <?= htmlspecialchars($application['secondary_completion_year']) ?></p>
                        <p><strong>Index Number:</strong> <?= htmlspecialchars($application['secondary_index_number']) ?></p>
                    </div>
                </div>

                <?php if (!empty($application['advanced_school'])): ?>
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Advanced Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Advanced School:</strong> <?= htmlspecialchars($application['advanced_school']) ?></p>
                        <p><strong>Index Number:</strong> <?= htmlspecialchars($application['advanced_index_number']) ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Parent/Guardian Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Name:</strong> <?= htmlspecialchars($application['parent_name']) ?></p>
                                <p><strong>Phone Number:</strong> <?= htmlspecialchars($application['parent_phone']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Address:</strong> <?= htmlspecialchars($application['parent_address']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($application['payment_status'] === 'pending'): ?>
        <div class="alert alert-warning mt-4">
            <h5><i class="bi bi-exclamation-triangle-fill"></i> Payment Pending</h5>
            <p>This application has not been paid for yet (Tsh 20,000/=).</p>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between mt-4">
            <a href="applications.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Back to Applications
            </a>
            <div>
            <button class="btn btn-outline-primary mt-3" onclick="printApplication()">
    <i class="fas fa-print"></i> Print Application
</button>
              <!--  <a href="edit_application.php?id=<?= $application['id'] ?>" class="btn btn-warning me-2">
                    <i class="bi bi-pencil"></i> Edit Application
                </a> -->
                <div class="btn-group">
                    <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="bi bi-gear"></i> Update Status
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="update_status.php?id=<?= $application['id'] ?>&status=approved">Approve Application</a></li>
                        <li><a class="dropdown-item" href="update_status.php?id=<?= $application['id'] ?>&status=rejected">Reject Application</a></li>
                        <li><a class="dropdown-item" href="update_status.php?id=<?= $application['id'] ?>&status=pending">Set as Pending</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>







<!-- Add this section to view_application.php -->
<div class="card mt-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="mb-0"><i class="bi bi-paperclip"></i> Attached Documents</h5>
    </div>
    <div class="card-body">
        <?php if ($application['attachment_path']): ?>
            <?php
            $fileIcon = '';
            $fileType = '';
            
            if (strpos($application['attachment_type'], 'pdf') !== false) {
                $fileIcon = 'bi-file-earmark-pdf-fill text-danger fs-1';
                $fileType = 'PDF Document';
            } else {
                $fileIcon = 'bi-file-earmark-word-fill text-primary fs-1';
                $fileType = 'Word Document';
            }
            ?>
            
            <div class="d-flex align-items-center">
                <i class="bi <?= $fileIcon ?> me-3"></i>
                <div>
                    <h6 class="mb-1"><?= $fileType ?></h6>
                    <p class="mb-0 text-muted"><?= round($application['attachment_size']/1024, 2) ?> KB</p>
                </div>
                <div class="ms-auto">
                    <a href="<?= $application['attachment_path'] ?>" class="btn btn-sm btn-outline-primary" download>
                        <i class="bi bi-download"></i> Download
                    </a>
                    <a href="<?= $application['attachment_path'] ?>" class="btn btn-sm btn-outline-secondary" target="_blank">
                        <i class="bi bi-eye"></i> View
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> No documents attached to this application
            </div>
        <?php endif; ?>
    </div>
</div>











<script>
function printApplication() {
    window.print(); // Hii itachapisha kila kitu kilicho kwenye ukurasa kwa sasa
}
</script>

<?php include '../includes/footer.php'; ?>