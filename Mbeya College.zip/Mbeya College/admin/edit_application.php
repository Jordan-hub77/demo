<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];

// Get application details
$stmt = $pdo->prepare("SELECT * FROM applications WHERE id = ?");
$stmt->execute([$application_id]);
$application = $stmt->fetch();

if (!$application) {
    $_SESSION['error'] = "Application not found";
    redirect('applications.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect all form data
    $data = [
        'full_name' => $_POST['full_name'],
        'birth_date' => $_POST['birth_date'],
        'secondary_school' => $_POST['secondary_school'],
        'secondary_completion_year' => $_POST['secondary_completion_year'],
        'secondary_index_number' => $_POST['secondary_index_number'],
        'district' => $_POST['district'],
        'region' => $_POST['region'],
        'phone' => $_POST['phone'],
        'primary_school' => $_POST['primary_school'],
        'advanced_school' => $_POST['advanced_school'] ?? null,
        'advanced_index_number' => $_POST['advanced_index_number'] ?? null,
        'parent_name' => $_POST['parent_name'],
        'parent_phone' => $_POST['parent_phone'],
        'parent_address' => $_POST['parent_region'] . ', ' . $_POST['parent_district'],
        'application_status' => $_POST['application_status'],
        'payment_status' => $_POST['payment_status'],
        'id' => $application_id
    ];
    
    try {
        $stmt = $pdo->prepare("UPDATE applications SET
            full_name = :full_name,
            birth_date = :birth_date,
            secondary_school = :secondary_school,
            secondary_completion_year = :secondary_completion_year,
            secondary_index_number = :secondary_index_number,
            district = :district,
            region = :region,
            phone = :phone,
            primary_school = :primary_school,
            advanced_school = :advanced_school,
            advanced_index_number = :advanced_index_number,
            parent_name = :parent_name,
            parent_phone = :parent_phone,
            parent_address = :parent_address,
            application_status = :application_status,
            payment_status = :payment_status
            WHERE id = :id");
        
        $stmt->execute($data);
        
        $_SESSION['success'] = "Application updated successfully!";
        redirect('view_application.php?id=' . $application_id);
    } catch (PDOException $e) {
        $_SESSION['error'] = "Update failed: " . $e->getMessage();
    }
}

// Parse parent address
$parent_address = explode(', ', $application['parent_address']);
$parent_region = $parent_address[0] ?? '';
$parent_district = $parent_address[1] ?? '';
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0"><i class="bi bi-pencil-square"></i> Edit Application</h4>
    </div>
    <div class="card-body">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <form method="POST">
            <div class="row">
                <div class="col-md-6">
                    <h5 class="mt-4">Personal Information</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="full_name" value="<?= htmlspecialchars($application['full_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" name="birth_date" value="<?= htmlspecialchars($application['birth_date']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" name="phone" value="<?= htmlspecialchars($application['phone']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Region</label>
                        <input type="text" class="form-control" name="region" value="<?= htmlspecialchars($application['region']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">District</label>
                        <input type="text" class="form-control" name="district" value="<?= htmlspecialchars($application['district']) ?>" required>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <h5 class="mt-4">Education Information</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Primary School</label>
                        <input type="text" class="form-control" name="primary_school" value="<?= htmlspecialchars($application['primary_school']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Secondary School</label>
                        <input type="text" class="form-control" name="secondary_school" value="<?= htmlspecialchars($application['secondary_school']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Completion Year</label>
                        <input type="number" class="form-control" name="secondary_completion_year" value="<?= htmlspecialchars($application['secondary_completion_year']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Index Number (Form 4)</label>
                        <input type="text" class="form-control" name="secondary_index_number" value="<?= htmlspecialchars($application['secondary_index_number']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Advanced School (if any)</label>
                        <input type="text" class="form-control" name="advanced_school" value="<?= htmlspecialchars($application['advanced_school'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Index Number (Form 6)</label>
                        <input type="text" class="form-control" name="advanced_index_number" value="<?= htmlspecialchars($application['advanced_index_number'] ?? '') ?>">
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5>Parent/Guardian Information</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Parent/Guardian Name</label>
                        <input type="text" class="form-control" name="parent_name" value="<?= htmlspecialchars($application['parent_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Parent/Guardian Phone</label>
                        <input type="tel" class="form-control" name="parent_phone" value="<?= htmlspecialchars($application['parent_phone']) ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <h5>Parent/Guardian Address</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Region</label>
                        <input type="text" class="form-control" name="parent_region" value="<?= htmlspecialchars($parent_region) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">District</label>
                        <input type="text" class="form-control" name="parent_district" value="<?= htmlspecialchars($parent_district) ?>" required>
                    </div>
                </div>
            </div>
            
            <?php if (isAdmin()): ?>
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5>Application Status</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="application_status" required>
                            <option value="pending" <?= $application['application_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="approved" <?= $application['application_status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                            <option value="rejected" <?= $application['application_status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <h5>Payment Status</h5>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="payment_status" required>
                            <option value="pending" <?= $application['payment_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="paid" <?= $application['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                        </select>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between mt-4">
                <a href="view_application.php?id=<?= $application_id ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>