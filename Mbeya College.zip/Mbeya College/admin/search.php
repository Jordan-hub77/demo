<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

$search_results = [];
$search_term = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
    
    if (!empty($search_term)) {
        $stmt = $pdo->prepare("
            SELECT a.*, u.username 
            FROM applications a 
            JOIN users u ON a.user_id = u.id 
            WHERE a.full_name LIKE ? OR 
                  a.secondary_index_number LIKE ? OR 
                  a.phone LIKE ? OR 
                  u.username LIKE ?
            ORDER BY a.submitted_at DESC
        ");
        $search_param = "%$search_term%";
        $stmt->execute([$search_param, $search_param, $search_param, $search_param]);
        $search_results = $stmt->fetchAll();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0">Search Applicants</h4>
    </div>
    <div class="card-body">
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Search by name, index number, phone or username..." 
                       value="<?= htmlspecialchars($search_term) ?>">
                <button class="btn btn-success" type="submit">
                    <i class="bi bi-search"></i> Search
                </button>
            </div>
        </form>
        
        <?php if (!empty($search_term)): ?>
            <h5>Search Results for "<?= htmlspecialchars($search_term) ?>"</h5>
            
            <?php if (empty($search_results)): ?>
                <div class="alert alert-info">No applications found matching your search criteria.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Application Date</th>
                                <th>Applicant</th>
                                <th>Full Name</th>
                                <th>Secondary School</th>
                                <th>Payment Status</th>
                                <th>Application Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($search_results as $index => $app): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= date('d/m/Y', strtotime($app['submitted_at'])) ?></td>
                                    <td><?= htmlspecialchars($app['username']) ?></td>
                                    <td><?= htmlspecialchars($app['full_name']) ?></td>
                                    <td><?= htmlspecialchars($app['secondary_school']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $app['payment_status'] === 'paid' ? 'success' : 'warning' ?>">
                                            <?= ucfirst($app['payment_status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= 
                                            $app['application_status'] === 'approved' ? 'success' : 
                                            ($app['application_status'] === 'rejected' ? 'danger' : 'warning') 
                                        ?>">
                                            <?= ucfirst($app['application_status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye"></i> View
                                        </a>
                                        <a href="edit_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>