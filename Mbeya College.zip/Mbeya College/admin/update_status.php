<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

if (!isset($_GET['id']) || !isset($_GET['status'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];
$new_status = $_GET['status'];

// Validate status
$allowed_statuses = ['approved', 'rejected', 'pending'];
if (!in_array($new_status, $allowed_statuses)) {
    $_SESSION['error'] = "Invalid status provided.";
    redirect('applications.php');
}

// Update application status
try {
    $stmt = $pdo->prepare("UPDATE applications SET application_status = ? WHERE id = ?");
    $stmt->execute([$new_status, $application_id]);
    
    // Get application details for notification
    $stmt = $pdo->prepare("SELECT user_id FROM applications WHERE id = ?");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch();
    
    if ($application) {
        // Record status change in notifications table
        $message = "Your application status has been updated to: " . ucfirst($new_status);
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, application_id, message, is_read) VALUES (?, ?, ?, 0)");
        $stmt->execute([$application['user_id'], $application_id, $message]);
    }
    
    $_SESSION['success'] = "Application status updated successfully!";
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to update application status: " . $e->getMessage();
}

redirect('view_application.php?id=' . $application_id);
?>