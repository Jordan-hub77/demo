<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Get all applications with user details
$stmt = $pdo->query("
    SELECT a.*, u.username 
    FROM applications a 
    JOIN users u ON a.user_id = u.id 
    ORDER BY a.submitted_at DESC
");
$applications = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0">All Applications</h4>
        <button class="btn btn-outline-primary mt-3" style="marging-top: -50px;"><a href="search.php"> <i class="fas fa-print"></i>Search</a>
        </button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Application Date</th>
                        <th>Applicant</th>
                        <th>Full Name</th>
                        <th>Secondary School</th>
                        <th>Payment Status</th>
                        <th>Application Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $index => $app): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= date('d/m/Y', strtotime($app['submitted_at'])) ?></td>
                            <td><?= htmlspecialchars($app['username']) ?></td>
                            <td><?= htmlspecialchars($app['full_name']) ?></td>
                            <td><?= htmlspecialchars($app['secondary_school']) ?></td>
                            <td>
                                <span class="badge bg-<?= $app['payment_status'] === 'paid' ? 'success' : 'warning' ?>">
                                    <?= ucfirst($app['payment_status']) ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?= 
                                    $app['application_status'] === 'approved' ? 'success' : 
                                    ($app['application_status'] === 'rejected' ? 'danger' : 'warning') 
                                ?>">
                                    <?= ucfirst($app['application_status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="view_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye"></i> View
                                </a>
                                <a href="edit_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>