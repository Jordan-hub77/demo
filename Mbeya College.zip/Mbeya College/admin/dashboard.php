<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Get total applications
$stmt = $pdo->query("SELECT COUNT(*) as total_applications FROM applications");
$total_applications = $stmt->fetch();

// Get pending applications
$stmt = $pdo->query("SELECT COUNT(*) as pending_applications FROM applications WHERE application_status = 'pending'");
$pending_applications = $stmt->fetch();

// Get approved applications
$stmt = $pdo->query("SELECT COUNT(*) as approved_applications FROM applications WHERE application_status = 'approved'");
$approved_applications = $stmt->fetch();

// Get paid applications
$stmt = $pdo->query("SELECT COUNT(*) as paid_applications FROM applications WHERE payment_status = 'paid'");
$paid_applications = $stmt->fetch();
?>

<?php include '../includes/header.php'; ?>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Applications</h5>
                <h2 class="card-text"><?= $total_applications['total_applications'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <h5 class="card-title">Pending Applications</h5>
                <h2 class="card-text"><?= $pending_applications['pending_applications'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Approved Applications</h5>
                <h2 class="card-text"><?= $approved_applications['approved_applications'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Paid Applications</h5>
                <h2 class="card-text"><?= $paid_applications['paid_applications'] ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-secondary text-white">
        <h4 class="mb-0">Quick Actions</h4>
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex justify-content-md-start">
            <a href="applications.php" class="btn btn-primary me-md-2">
                <i class="bi bi-list-ul"></i> View Applications
            </a>
            <a href="search.php" class="btn btn-success me-md-2">
                <i class="bi bi-search"></i> Search Applicants
            </a>
            <a href="profile.php" class="btn btn-warning">
                <i class="bi bi-person"></i> My Profile
            </a>
            <a href="application_settings.php" class="btn btn-sm btn-outline-dark ms-3">
            <i class="bi bi-gear"></i> Manage Session
        </a>
        </div>
    </div>
</div>
<!-- admin/dashboard.php -->


<?php include '../includes/footer.php'; ?>


<div class="alert <?= isApplicationPeriodOpen() ? 'alert-success' : 'alert-danger' ?>">
    <i class="bi bi-<?= isApplicationPeriodOpen() ? 'unlock' : 'lock' ?>"></i>
    Applications are currently <?= isApplicationPeriodOpen() ? 'OPEN' : 'CLOSED' ?>
    
    <?php if (!isApplicationPeriodOpen()): ?>
       
    <?php endif; ?>
</div>