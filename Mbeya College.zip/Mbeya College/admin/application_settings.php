<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Pata mipangilio ya sasa
$stmt = $pdo->query("SELECT * FROM application_settings LIMIT 1");
$settings = $stmt->fetch();

// Shughuli za kuhifadhi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $opening_time = !empty($_POST['opening_time']) ? $_POST['opening_time'] : null;
    $closing_time = !empty($_POST['closing_time']) ? $_POST['closing_time'] : null;

    try {
        $stmt = $pdo->prepare("
            UPDATE application_settings 
            SET is_active = ?, opening_time = ?, closing_time = ?, 
                updated_at = NOW(), updated_by = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $is_active,
            $opening_time,
            $closing_time,
            $_SESSION['user_id'],
            $settings['id']
        ]);

        $_SESSION['success'] = "Application settings updated successfully!";
        redirect('application_settings.php');
    } catch (PDOException $e) {
        $_SESSION['error'] = "Failed to update settings: " . $e->getMessage();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0"><i class="bi bi-gear"></i> Application Period Settings</h4>
    </div>
    <div class="card-body">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3 form-check form-switch">
                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" 
                    <?= $settings['is_active'] ? 'checked' : '' ?>>
                <label class="form-check-label" for="is_active">Enable Applications</label>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="opening_time" class="form-label">Opening Time</label>
                    <input type="datetime-local" class="form-control" id="opening_time" name="opening_time"
                        value="<?= $settings['opening_time'] ? date('Y-m-d\TH:i', strtotime($settings['opening_time'])) : '' ?>">
                </div>
                <div class="col-md-6">
                    <label for="closing_time" class="form-label">Closing Time</label>
                    <input type="datetime-local" class="form-control" id="closing_time" name="closing_time"
                        value="<?= $settings['closing_time'] ? date('Y-m-d\TH:i', strtotime($settings['closing_time'])) : '' ?>">
                </div>
            </div>

            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> 
                Current Server Time: <?= date('Y-m-d H:i:s') ?>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save"></i> Save Session
            </button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>