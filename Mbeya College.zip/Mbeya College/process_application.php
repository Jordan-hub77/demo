<?php
require_once 'includes/config.php';

file_put_contents('debug.log', "Processing application at: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

if (!isLoggedIn()) {
    $_SESSION['error'] = "Unauthorized access";
    redirect('login.php');
}

if (isAdmin()) {
    redirect('admin/dashboard.php');
}

// Angalia kama user tayari ana application
$checkStmt = $pdo->prepare("SELECT id FROM applications WHERE user_id = ?");
$checkStmt->execute([$_SESSION['user_id']]);
if ($checkStmt->fetch()) {
    $_SESSION['error'] = "You have already submitted an application";
    redirect('user/apply.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    file_put_contents('debug.log', "POST data: " . print_r($_POST, true) . "\n", FILE_APPEND);

    // Collect data
    $data = [
        'user_id' => $_SESSION['user_id'],
        'full_name' => $_POST['full_name'] ?? '',
        'birth_date' => $_POST['birth_date'] ?? '',
        'secondary_school' => $_POST['secondary_school'] ?? '',
        'secondary_completion_year' => $_POST['secondary_completion_year'] ?? '',
        'secondary_index_number' => $_POST['secondary_index_number'] ?? '',
        'district' => $_POST['district'] ?? '',
        'region' => $_POST['region'] ?? '',
        'phone' => $_POST['phone'] ?? '',
        'primary_school' => $_POST['primary_school'] ?? '',
        'advanced_school' => $_POST['advanced_school'] ?? '',
        'advanced_index_number' => $_POST['advanced_index_number'] ?? '',
        'parent_name' => $_POST['parent_name'] ?? '',
        'parent_phone' => $_POST['parent_phone'] ?? '',
        'parent_address' => $_POST['parent_address'] ?? '',
    ];

    // File upload
    $attachmentPath = null;
    if (isset($_FILES['attachment'])) {
        file_put_contents('debug.log', "File upload info: " . print_r($_FILES['attachment'], true) . "\n", FILE_APPEND);

        if ($_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ];
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $fileType = $finfo->file($_FILES['attachment']['tmp_name']);

            if (in_array($fileType, $allowedTypes)) {
                $extension = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
                $fileName = uniqid('app_', true) . '.' . $extension;
                $uploadPath = UPLOAD_DIR . $fileName;

                if (move_uploaded_file($_FILES['attachment']['tmp_name'], $uploadPath)) {
                    $attachmentPath = $uploadPath;
                }
            }
        }
    }

    try {
        $sql = "INSERT INTO applications (
            user_id, full_name, birth_date, secondary_school,
            secondary_completion_year, secondary_index_number, district,
            region, phone, primary_school, advanced_school,
            advanced_index_number, parent_name, parent_phone,
            parent_address, attachment_path
        ) VALUES (
            :user_id, :full_name, :birth_date, :secondary_school,
            :secondary_completion_year, :secondary_index_number, :district,
            :region, :phone, :primary_school, :advanced_school,
            :advanced_index_number, :parent_name, :parent_phone,
            :parent_address, :attachment_path
        )";

        $stmt = $pdo->prepare($sql);

        // Bind params
        foreach ($data as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        $stmt->bindValue(':attachment_path', $attachmentPath);

        if ($stmt->execute()) {
            $lastId = $pdo->lastInsertId();
            file_put_contents('debug.log', "Insert successful. Last ID: $lastId\n", FILE_APPEND);
            $_SESSION['success'] = "Application submitted successfully!";
            redirect('user/applications.php');
        } else {
            throw new Exception("Execute statement failed");
        }
    } catch (PDOException $e) {
        $errorMsg = "Database error: " . $e->getMessage();
        file_put_contents('debug.log', $errorMsg . "\n", FILE_APPEND);
        $_SESSION['error'] = $errorMsg;
        redirect('user/apply.php');
    }
} else {
    $_SESSION['error'] = "Invalid request method";
    redirect('user/apply.php');
}
?>



