
DROP DATABASE IF EXISTS `mbeya_college`; 

CREATE DATABASE mbeya_college;
USE mbeya_college;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Applications table
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    secondary_school VARCHAR(100) NOT NULL,
    secondary_completion_year INT NOT NULL,
    secondary_index_number VARCHAR(20) NOT NULL,
    district VARCHAR(50) NOT NULL,
    region VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    primary_school VARCHAR(100) NOT NULL,
    advanced_school VARCHAR(100),
    advanced_index_number VARCHAR(20),
    parent_name VARCHAR(100) NOT NULL,
    parent_phone VARCHAR(20) NOT NULL,
    parent_address VARCHAR(100) NOT NULL,
    payment_status ENUM('pending', 'paid') DEFAULT 'pending',
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    payment_date DATETIME,
    application_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    attachment_path VARCHAR(255),
    attachment_type VARCHAR(50),
    attachment_size INT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Notifications table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    application_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (application_id) REFERENCES applications(id)
);