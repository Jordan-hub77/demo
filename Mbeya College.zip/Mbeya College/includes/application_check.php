<?php
require_once 'config.php';

// Pata mipangilio ya maombi
$stmt = $pdo->query("SELECT * FROM application_settings LIMIT 1");
$settings = $stmt->fetch();

// Kukagua kama mda wa maombi umefungwa
function isApplicationPeriodOpen() {
    global $settings;
    
    // Kama mfumo umefungwa kabisa
    if (!$settings['is_active']) {
        return false;
    }
    
    $current_time = time();
    $opening_time = strtotime($settings['opening_time']);
    $closing_time = strtotime($settings['closing_time']);
    
    // Kama hakuna mda maalum umewekwa
    if (is_null($settings['opening_time']) && is_null($settings['closing_time'])) {
        return true;
    }
    
    // Kama mda umewekwa
    if (!is_null($settings['opening_time']) && $current_time < $opening_time) {
        return false;
    }
    
    if (!is_null($settings['closing_time']) && $current_time > $closing_time) {
        return false;
    }
    
    return true;
}

// Redirect ikiwa mda wa maombi umefungwa (kwa wale si admin)

if (!isAdmin() && !isApplicationPeriodOpen() && basename($_SERVER['PHP_SELF']) != 'application_closed.php') {
    redirect('application_closed.php');
    exit;
}
?>