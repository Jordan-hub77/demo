</div>
<footer class="bg-dark text-light py-4 mt-5">
    <div class="container">
        <div class="row">
            <!-- How to Apply Section -->
            <div class="col-md-12">
                <h5 class="text-uppercase mb-3">HOW TO APPLY</h5>
                <p>
                    Applying to various Programmes at <strong>Mbeya College of Agriculture (MCA)</strong> for the Academic Year <strong>2025/2026</strong><br>
                    All applicants for <strong>Certificate and Diploma Programmes</strong> should apply online through the University website:<br>
                    <a href="http://www.mbeyacollege.ac.tz" class="text-warning" target="_blank">www.mbeyacollege.ac.tz</a><br>
                    Or you can download the application form from the link <strong>[xxxx]</strong>, fill it, and send it via college email:<br>
                    <a href="mailto:mpc.tukuyucampus@gmail.com" class="text-warning">mpc.tukuyucampus@gmail.com</a> along with the application fee attachment.
                </p>
            </div>
        </div>
        <hr class="bg-light">
        <div class="text-center small">
            &copy; <?= date('Y') ?> Mbeya College of Agriculture. All rights reserved.
        </div>
        <div class="text-center small">
        <p>Powered By <a href="https://kenosis.co.tz"> Kenosis Technologies</a></p>

             
        </div>
    </div>
</footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
 