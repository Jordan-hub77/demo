<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];

// Get application details
$stmt = $pdo->prepare("SELECT * FROM applications WHERE id = ? AND user_id = ?");
$stmt->execute([$application_id, $_SESSION['user_id']]);
$application = $stmt->fetch();

if (!$application) {
    $_SESSION['error'] = "Application not found or you don't have permission to view it.";
    redirect('applications.php');
}
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0">Application Details</h4>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5>Application Status:</h5>
                    <span class="badge bg-<?= 
                        $application['application_status'] === 'approved' ? 'success' : 
                        ($application['application_status'] === 'rejected' ? 'danger' : 'warning') 
                    ?> fs-6">
                        <?= ucfirst($application['application_status']) ?>
                    </span>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5>Payment Status:</h5>
                    <span class="badge bg-<?= $application['payment_status'] === 'paid' ? 'success' : 'warning' ?> fs-6">
                        <?= ucfirst($application['payment_status']) ?>
                    </span>
                </div>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-2"><strong>Application Date:</strong> <?= date('d/m/Y H:i', strtotime($application['submitted_at'])) ?></p>
                <p><strong>Application ID:</strong> MCA-<?= str_pad($application['id'], 5, '0', STR_PAD_LEFT) ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Personal Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Full Name:</strong> <?= htmlspecialchars($application['full_name']) ?></p>
                        <p><strong>Date of Birth:</strong> <?= date('d/m/Y', strtotime($application['birth_date'])) ?></p>
                        <p><strong>Phone Number:</strong> <?= htmlspecialchars($application['phone']) ?></p>
                        <p><strong>Region:</strong> <?= htmlspecialchars($application['region']) ?></p>
                        <p><strong>District:</strong> <?= htmlspecialchars($application['district']) ?></p>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Primary Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Primary School:</strong> <?= htmlspecialchars($application['primary_school']) ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Secondary Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Secondary School:</strong> <?= htmlspecialchars($application['secondary_school']) ?></p>
                        <p><strong>Completion Year:</strong> <?= htmlspecialchars($application['secondary_completion_year']) ?></p>
                        <p><strong>Index Number:</strong> <?= htmlspecialchars($application['secondary_index_number']) ?></p>
                    </div>
                </div>

                <?php if (!empty($application['advanced_school'])): ?>
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Advanced Education</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Advanced School:</strong> <?= htmlspecialchars($application['advanced_school']) ?></p>
                        <p><strong>Index Number:</strong> <?= htmlspecialchars($application['advanced_index_number']) ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Parent/Guardian Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Name:</strong> <?= htmlspecialchars($application['parent_name']) ?></p>
                                <p><strong>Phone Number:</strong> <?= htmlspecialchars($application['parent_phone']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Address:</strong> <?= htmlspecialchars($application['parent_address']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<!-- Add this after parent information section -->
<div class="card mt-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="mb-0"><i class="bi bi-paperclip"></i> Attached Documents</h5>
    </div>
    <div class="card-body">
        <?php if ($application['attachment_path']): ?>
            <?php
            $fileIcon = '';
            $fileType = '';
            
            if (strpos($application['attachment_type'], 'pdf') !== false) {
                $fileIcon = 'bi-file-earmark-pdf-fill text-danger';
                $fileType = 'PDF Document';
            } elseif (strpos($application['attachment_type'], 'word') !== false || 
                     strpos($application['attachment_type'], 'document') !== false) {
                $fileIcon = 'bi-file-earmark-word-fill text-primary';
                $fileType = 'Word Document';
            }
            
            $fileSize = round($application['attachment_size'] / 1024, 2); // Convert to KB
            ?>
            
            <div class="d-flex align-items-center">
                <i class="bi <?= $fileIcon ?> fs-3 me-3"></i>
                <div>
                    <h6 class="mb-1"><?= $fileType ?></h6>
                    <p class="mb-0 text-muted"><?= $fileSize ?> KB</p>
                </div>
                <div class="ms-auto">
                    <a href="<?= $application['attachment_path'] ?>" class="btn btn-sm btn-outline-primary" download>
                        <i class="bi bi-download"></i> Download
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> No documents attached
            </div>
        <?php endif; ?>
    </div>
</div>

        <?php if ($application['payment_status'] === 'pending'): ?>
        <div class="alert alert-warning mt-4">
            <h5><i class="bi bi-exclamation-triangle-fill"></i> Payment Required</h5>
            <p>To complete your application, please make a payment of Tsh 20,000/= using one of the following methods:</p>
            <ul>
                <li><strong>M-Pesa:</strong> Send to 0757555555 (Mbeya College of Agriculture)</li>
                <li><strong>Tigo Pesa:</strong> Send to 0657555555</li>
                <li><strong>Airtel Money:</strong> Send to 0787555555</li>
            </ul>
            <p>After payment, contact the admissions office with your payment details for verification.</p>
            <a href="make_payment.php?id=<?= $application['id'] ?>" class="btn btn-success mt-2">
                <i class="bi bi-credit-card"></i> Confirm Payment
            </a>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between mt-4">
            <a href="applications.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Back to Applications
            </a>
            <div>
            <button class="btn btn-outline-primary mt-3" onclick="printApplication()">
    <i class="fas fa-print"></i> Print Application
</button>
              <!--  <?php if ($application['application_status'] === 'pending'): ?>
                <a href="edit_application.php?id=<?= $application['id'] ?>" class="btn btn-warning">
                    <i class="bi bi-pencil"></i> Edit Application
                </a> -->
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function printApplication() {
    window.print(); // Hii itachapisha kila kitu kilicho kwenye ukurasa kwa sasa
}
</script>
