<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];

// Verify application belongs to user
$stmt = $pdo->prepare("SELECT * FROM applications WHERE id = ? AND user_id = ?");
$stmt->execute([$application_id, $_SESSION['user_id']]);
$application = $stmt->fetch();

if (!$application) {
    $_SESSION['error'] = "Application not found";
    redirect('applications.php');
}

if ($application['payment_status'] === 'paid') {
    $_SESSION['info'] = "Payment already completed for this application";
    redirect('view_application.php?id='.$application_id);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];
    
    // Validate payment
    if (empty($transaction_id)) {
        $_SESSION['error'] = "Transaction ID is required";
    } else {
        try {
            // Update payment status
            $stmt = $pdo->prepare("UPDATE applications SET payment_status = 'paid', payment_method = ?, transaction_id = ?, payment_date = NOW() WHERE id = ?");
            $stmt->execute([$payment_method, $transaction_id, $application_id]);
            
            $_SESSION['success'] = "Payment confirmed successfully!";
            redirect('view_application.php?id='.$application_id);
        } catch (PDOException $e) {
            $_SESSION['error'] = "Payment confirmation failed: " . $e->getMessage();
        }
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0"><i class="bi bi-credit-card"></i> Complete Payment</h4>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Payment Details</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Application ID:</strong> MCA-<?= str_pad($application['id'], 5, '0', STR_PAD_LEFT) ?></p>
                        <p><strong>Amount:</strong> Tsh 20,000/=</p>
                        <p><strong>Due Date:</strong> <?= date('d/m/Y', strtotime('+3 days')) ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Payment Methods</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <div class="list-group-item">
                                <h6><i class="bi bi-phone text-success"></i> M-Pesa</h6>
                                <ol>
                                    <li>Go to M-Pesa menu</li>
                                    <li>Select Lipa na M-Pesa</li>
                                    <li>Enter Paybill: 123456</li>
                                    <li>Account: MCA-<?= str_pad($application['id'], 5, '0', STR_PAD_LEFT) ?></li>
                                    <li>Amount: 20000</li>
                                </ol>
                            </div>
                            <div class="list-group-item">
                                <h6><i class="bi bi-bank text-primary"></i> Bank Deposit</h6>
                                <p>Deposit to:<br>
                                <strong>Bank Name:</strong> CRDB<br>
                                <strong>Account Name:</strong> Mbeya College of Agriculture<br>
                                <strong>Account Number:</strong> 0151234567890</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Confirm Payment</h5>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                            <?php unset($_SESSION['error']); ?>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="payment_method" class="form-label">Payment Method</label>
                                <select class="form-select" id="payment_method" name="payment_method" required>
                                    <option value="">Select method</option>
                                    <option value="mpesa">M-Pesa</option>
                                    <option value="tigopesa">Tigo Pesa</option>
                                    <option value="airtel">Airtel Money</option>
                                    <option value="bank">Bank Deposit</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="transaction_id" class="form-label">Transaction ID/Reference</label>
                                <input type="text" class="form-control" id="transaction_id" name="transaction_id" required>
                                <small class="text-muted">Enter the transaction ID you received after payment</small>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="bi bi-check-circle"></i> Confirm Payment
                                </button>
                                <a href="applications.php" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left"></i> Back to Applications
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>