<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('applications.php');
}

$application_id = $_GET['id'];

// Verify application belongs to user and is still editable
$stmt = $pdo->prepare("SELECT * FROM applications WHERE id = ? AND user_id = ? AND application_status = 'pending'");
$stmt->execute([$application_id, $_SESSION['user_id']]);
$application = $stmt->fetch();

if (!$application) {
    $_SESSION['error'] = "Application not found or cannot be edited";
    redirect('applications.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Similar update logic as admin but without status fields
    $data = [
        'full_name' => $_POST['full_name'],
        // ... (all other fields except status fields)
        'id' => $application_id
    ];
    
    try {
        $stmt = $pdo->prepare("UPDATE applications SET
            full_name = :full_name,
            // ... (all other fields)
            WHERE id = :id");
        
        $stmt->execute($data);
        
        $_SESSION['success'] = "Application updated successfully!";
        redirect('view_application.php?id=' . $application_id);
    } catch (PDOException $e) {
        $_SESSION['error'] = "Update failed: " . $e->getMessage();
    }
}

// Parse parent address
$parent_address = explode(', ', $application['parent_address']);
$parent_region = $parent_address[0] ?? '';
$parent_district = $parent_address[1] ?? '';
?>

<!-- Form would be similar to admin version but without the status sections -->