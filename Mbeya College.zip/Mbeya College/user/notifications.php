<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Mark notifications as read when user views this page
$pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$_SESSION['user_id']]);

// Get all notifications
$stmt = $pdo->prepare("
    SELECT n.*, a.id as app_id 
    FROM notifications n
    LEFT JOIN applications a ON n.application_id = a.id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$notifications = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0">My Notifications</h4>
    </div>
    <div class="card-body">
        <?php if (empty($notifications)): ?>
            <div class="alert alert-info">You don't have any notifications yet.</div>
        <?php else: ?>
            <div class="list-group">
                <?php foreach ($notifications as $notification): ?>
                <div class="list-group-item">
                    <div class="d-flex w-100 justify-content-between">
                        <p class="mb-1"><?= htmlspecialchars($notification['message']) ?></p>
                        <small><?= date('d/m/Y H:i', strtotime($notification['created_at'])) ?></small>
                    </div>
                    <?php if ($notification['app_id']): ?>
                    <a href="view_application.php?id=<?= $notification['app_id'] ?>" class="btn btn-sm btn-primary mt-2">
                        <i class="bi bi-eye"></i> View Application
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>