<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Get user applications
$stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY submitted_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<div class="card border-0 shadow">
    <div class="card-header bg-success text-white py-3">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="bi bi-file-earmark-text me-2"></i> My Applications</h4>
            <span class="badge bg-light text-dark fs-6">
                <?= count($applications) ?> application<?= count($applications) !== 1 ? 's' : '' ?>
            </span>
        </div>
    </div>
    <div class="card-body">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (empty($applications)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="bi bi-file-earmark-excel"></i>
                </div>
                <h4 class="mt-3">No Applications Found</h4>
                <p class="text-muted">You haven't submitted any applications yet. Click the button below to start your first application.</p>
                <a href="apply.php" class="btn new-application-btn mt-3">
                    <i class="bi bi-plus-circle me-1"></i> New Application
                </a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table applications-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Application Date</th>
                            <th>School Name</th>
                            <th>Payment Status</th>
                            <th>Application Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $index => $app): ?>
                            <tr>
                                <td class="fw-bold"><?= $index + 1 ?></td>
                                <td><?= date('d M Y', strtotime($app['submitted_at'])) ?></td>
                                <td><?= htmlspecialchars($app['secondary_school']) ?></td>
                                <td>
                                    <span class="status-badge badge-<?= $app['payment_status'] === 'paid' ? 'paid' : 'pending' ?>">
                                        <i class="bi bi-<?= $app['payment_status'] === 'paid' ? 'check-circle' : 'clock' ?> me-1"></i>
                                        <?= ucfirst($app['payment_status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="status-badge badge-<?= $app['application_status'] ?>">
                                        <i class="bi bi-<?= 
                                            $app['application_status'] === 'approved' ? 'check-circle' : 
                                            ($app['application_status'] === 'rejected' ? 'x-circle' : 'hourglass') 
                                        ?> me-1"></i>
                                        <?= ucfirst($app['application_status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-primary action-btn">
                                        <i class="bi bi-eye"></i> View
                                    </a>
                                    <?php if ($app['payment_status'] === 'pending'): ?>
                                        <a href="make_payment.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-success action-btn">
                                            <i class="bi bi-credit-card"></i> Pay
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div>
                    <a href="apply.php" class="btn new-application-btn">
                        <i class="bi bi-plus-circle me-1"></i> New Application
                    </a>
                </div>
                <div class="text-muted">
                    Showing <?= count($applications) ?> application<?= count($applications) !== 1 ? 's' : '' ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>