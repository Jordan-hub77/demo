<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Get user applications count
$stmt = $pdo->prepare("SELECT COUNT(*) as total_applications FROM applications WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetch();

// Get pending applications
$stmt = $pdo->prepare("SELECT COUNT(*) as pending_applications FROM applications WHERE user_id = ? AND application_status = 'pending'");
$stmt->execute([$_SESSION['user_id']]);
$pending = $stmt->fetch();

// Get approved applications
$stmt = $pdo->prepare("SELECT COUNT(*) as approved_applications FROM applications WHERE user_id = ? AND application_status = 'approved'");
$stmt->execute([$_SESSION['user_id']]);
$approved = $stmt->fetch();

// Get unread notifications
$stmt = $pdo->prepare("SELECT COUNT(*) as unread_notifications FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$_SESSION['user_id']]);
$notifications = $stmt->fetch();
?>

<?php include '../includes/header.php'; ?>

<!-- Notification Bell -->
<div class="position-absolute top-0 end-0 mt-3 me-3">
    <a href="notifications.php" class="btn btn-primary position-relative">
        <i class="bi bi-bell"></i>
        <?php if ($notifications['unread_notifications'] > 0): ?>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            <?= $notifications['unread_notifications'] ?>
        </span>
        <?php endif; ?>
    </a>
</div>

<div class="row mt-4">
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Applications</h5>
                <h2 class="card-text"><?= $applications['total_applications'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <h5 class="card-title">Pending Applications</h5>
                <h2 class="card-text"><?= $pending['pending_applications'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Approved Applications</h5>
                <h2 class="card-text"><?= $approved['approved_applications'] ?></h2>
            </div>
        </div>
    </div>
</div>

<!-- Recent Applications -->
<div class="card mb-4">
    <div class="card-header bg-info text-white">
        <h4 class="mb-0">Recent Applications</h4>
    </div>
    <div class="card-body">
        <?php
        $stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY submitted_at DESC LIMIT 3");
        $stmt->execute([$_SESSION['user_id']]);
        $recent_apps = $stmt->fetchAll();
        
        if (empty($recent_apps)): ?>
            <div class="alert alert-info">You haven't submitted any applications yet.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_apps as $index => $app): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= date('d/m/Y', strtotime($app['submitted_at'])) ?></td>
                            <td>
                                <span class="badge bg-<?= 
                                    $app['application_status'] === 'approved' ? 'success' : 
                                    ($app['application_status'] === 'rejected' ? 'danger' : 'warning') 
                                ?>">
                                    <?= ucfirst($app['application_status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="view_application.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye"></i> View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header bg-secondary text-white">
        <h4 class="mb-0">Quick Actions</h4>
    </div>
    <div class="card-body">
        <div class="d-grid gap-2 d-md-flex justify-content-md-start">
            <a href="apply.php" class="btn btn-success me-md-2">
                <i class="bi bi-plus-circle"></i> New Application
            </a>
            <a href="applications.php" class="btn btn-primary me-md-2">
                <i class="bi bi-list-ul"></i> View All Applications
            </a>
            <a href="profile.php" class="btn btn-warning">
                <i class="bi bi-person"></i> My Profile
            </a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>