
<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/application_check.php';


if (!isApplicationPeriodOpen()) {
    echo '<div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle"></i> 
        The application period is currently closed. Please check back later.
    </div>';
    include '../includes/footer.php';
    exit;
}


// Verify user is logged in
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Check if user already has an application
$stmt = $pdo->prepare("SELECT id, application_status, payment_status FROM applications WHERE user_id = ? LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$existingApplication = $stmt->fetch();

$alreadyApplied = $existingApplication !== false;
?>

<?php include '../includes/header.php'; ?>

<div class="card border-0 shadow">
    <div class="card-header bg-success text-white">
        <h4 class="mb-0"><i class="bi bi-file-earmark-text"></i> MBEYA COLLEGE OF AGRICULTURE - APPLICATION FORM</h4>
    </div>
    
    <div class="card-body">
        <?php if ($alreadyApplied): ?>
            <!-- Already Applied Section -->
            <div class="application-status-card status-<?= htmlspecialchars($existingApplication['application_status']) ?>">
                <div class="d-flex align-items-center mb-3">
                    <i class="bi bi-check-circle-fill fs-1 me-3"></i>
                    <div>
                        <h3 class="mb-1">Application Submitted Successfully!</h3>
                        <p class="mb-0" style="color: red; font-weight: bolder; font-size: 19px;">Unaruhusiwa Kufanya Maombi mara moja tu!</p>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Application Status</h6>
                                <span class="badge bg-<?= 
                                    $existingApplication['application_status'] === 'approved' ? 'success' : 
                                    ($existingApplication['application_status'] === 'rejected' ? 'danger' : 'warning') 
                                ?> fs-6 p-2">
                                    <?= strtoupper(htmlspecialchars($existingApplication['application_status'])) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="card-title text-muted">Payment Status</h6>
                                <span class="badge bg-<?= $existingApplication['payment_status'] === 'paid' ? 'success' : 'warning' ?> fs-6 p-2">
                                    <?= strtoupper(htmlspecialchars($existingApplication['payment_status'])) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-3">
                    <a href="view_application.php?id=<?= $existingApplication['id'] ?>" class="btn btn-primary me-md-2">
                        <i class="bi bi-eye"></i> View Application Details
                    </a>
                    <a href="applications.php" class="btn btn-outline-secondary">
                        <i class="bi bi-list-ul"></i> View All Applications
                    </a>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Application Form Section -->
            <form method="POST" action="../process_application.php" enctype="multipart/form-data" id="applicationForm">
                <!-- Personal Information -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success text-dark">
                        <h5 class="mb-0"><i class="bi bi-person"></i> PERSONAL INFORMATION</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Date of Birth <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="birth_date" min="1950-01-01" max="2008-12-31" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" name="phone" maxlength="10" pattern="\d{10}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Region <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="region" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">District <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="district" required>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Education Information -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success text-dark">
                        <h5 class="mb-0"><i class="bi bi-book"></i> EDUCATION INFORMATION</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Primary School <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="primary_school" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Secondary School <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="secondary_school" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Form 4 Completion Year <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="secondary_completion_year" min="1980" max="<?= date('Y') ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Form 4 Index Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="secondary_index_number" placeholder="S0123/4567" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Form 6 Index Number (If applicable)</label>
                                <input type="text" class="form-control" name="advanced_index_number" placeholder="S0123/4567">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Parent/Guardian Information -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success text-dark">
                        <h5 class="mb-0"><i class="bi bi-people"></i> PARENT/GUARDIAN INFORMATION</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Parent/Guardian Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="parent_name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Parent/Guardian Phone <span class="text-danger">*</span></label>
                                <input type="tel" id="parent_phone" class="form-control" name="parent_phone" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Region <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="parent_region" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">District <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="parent_district" required>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Document Upload -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success text-dark">
                        <h5 class="mb-0"><i class="bi bi-paperclip"></i> DOCUMENT ATTACHMENT</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Upload Supporting Documents (PDF or Word) <span class="text-danger">*</span></label>
                            <input type="file" class="form-control" name="attachment" accept=".pdf,.doc,.docx" required>
                            <small class="text-muted">Maximum file size: 5MB. Accepted formats: PDF, DOC, DOCX</small>
                        </div>
                    </div>
                </div>

                <!-- Payment Information -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success text-dark">
                        <h5 class="mb-0"><i class="bi bi-credit-card"></i> PAYMENT INFORMATION</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h6><i class="bi bi-info-circle"></i> Payment Instructions:</h6>
                            <p>After submitting this form, you will need to make a payment of <strong>Tsh 20,000/=</strong> to complete your application.</p>
                            <p>Payment methods: M-Pesa, Tigo Pesa, Airtel Money, or Bank Deposit</p>
                        </div>
                    </div>
                </div>

                <!-- Form Submission -->
                <div class="d-flex gap-3 mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-success btn-lg py-3">
                        <i class="bi bi-send"></i> Submit Application
                    </button>
                    <button type="reset" class="btn btn-outline-secondary btn-lg py-3">
                        <i class="bi bi-eraser"></i> Clear Form
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Phone number validation for applicant
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^\d]/g, '');
            if (this.value.length > 10) {
                this.value = this.value.slice(0, 10);
            }
        });
    }

    // Phone number validation for parent/guardian
    const parentPhoneInput = document.getElementById('parent_phone');
    if (parentPhoneInput) {
        parentPhoneInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^\d]/g, '');
            if (this.value.length > 10) {
                this.value = this.value.slice(0, 10);
            }
        });
    }

    // Form submission handler
    const applicationForm = document.getElementById('applicationForm');
    if (applicationForm) {
        applicationForm.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            if (submitBtn) {
                submitBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    Processing...
                `;
                submitBtn.disabled = true;
                
                // Fallback in case form submission fails
                setTimeout(() => {
                    submitBtn.innerHTML = `<i class="bi bi-send"></i> Submit Application`;
                    submitBtn.disabled = false;
                }, 5000);
            }
        });
    }
});
</script>

<?php include '../includes/footer.php'; ?>