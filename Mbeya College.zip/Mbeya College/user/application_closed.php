<?php
require_once '../includes/config.php';
require_once '../includes/application_check.php';
?>

<?php include '../includes/header.php'; ?>

<div class="card text-center mt-5">
    <div class="card-header bg-danger text-white">
        <h3><i class="bi bi-exclamation-triangle"></i> Applications Closed</h3>
    </div>
    <div class="card-body">
        <i class="bi bi-calendar-x fs-1 text-danger mb-3"></i>
        <h5 class="card-title">Application Period is Currently Closed</h5>
        
        <?php
        $stmt = $pdo->query("SELECT * FROM application_settings LIMIT 1");
        $settings = $stmt->fetch();
        
        if ($settings['opening_time'] || $settings['closing_time']): ?>
            <div class="alert alert-info mt-4">
                <p class="mb-1">
                    <?php if ($settings['opening_time']): ?>
                        Applications will open on: <strong><?= date('j F Y H:i', strtotime($settings['opening_time'])) ?></strong>
                    <?php endif; ?>
                    
                    <?php if ($settings['opening_time'] && $settings['closing_time']): ?>
                        <br>
                    <?php endif; ?>
                    
                    <?php if ($settings['closing_time']): ?>
                        Applications will close on: <strong><?= date('j F Y H:i', strtotime($settings['closing_time'])) ?></strong>
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
        
        <p class="card-text">Please check back later or contact the administration for more information.</p>
        <a href="../index.php" class="btn btn-primary mt-3">
            <i class="bi bi-house"></i> Return to Home
        </a>
    </div>
    <div class="card-footer text-muted">
        Current server time: <?= date('j F Y H:i:s') ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>