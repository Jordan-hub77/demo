<?php
require 'includes/config.php';
try {
    $stmt = $pdo->query("SELECT 1");
    echo "Database connection working!";
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>