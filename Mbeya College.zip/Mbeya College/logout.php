<?php
require_once 'includes/config.php';

// Fungua session na uhariri data zote
$_SESSION = array();

// Kama unataka kufuta kabisa session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Hariri session
session_destroy();

// Rudisha kwenye ukurasa wa kwanza
header("Location: index.php");
exit();
?>